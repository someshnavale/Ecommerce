package com.ecom.retail.service;

import com.ecom.retail.entity.Product;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface ProductService {


    List<Product> listActiveProducts();
   // List<Product> searchProducts(String productName, BigDecimal minPrice, BigDecimal maxPrice, LocalDateTime minDatePosted, LocalDateTime maxDatePosted);
    Product createProduct(Product product);
    Product updateProduct(Long productId, Product product);
    void deleteProduct(Long productId);


}



