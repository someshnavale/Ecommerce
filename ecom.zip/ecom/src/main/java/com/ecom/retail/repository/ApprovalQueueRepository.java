package com.ecom.retail.repository;

import com.ecom.retail.entity.ApprovalQueue;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ApprovalQueueRepository extends JpaRepository<ApprovalQueue,Long > {

    List<ApprovalQueue> findAllByOrderByCreatedAtAsc();

}
