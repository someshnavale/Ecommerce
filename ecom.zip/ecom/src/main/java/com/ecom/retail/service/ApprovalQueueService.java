package com.ecom.retail.service;

import com.ecom.retail.entity.ApprovalQueue;

import java.util.List;

public interface ApprovalQueueService {


        List<ApprovalQueue> getProductsInApprovalQueue();
        void approvalQueue(Long approvalId);
        void rejectedProduct(Long approvalId);

}
