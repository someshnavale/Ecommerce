package com.ecom.retail.service.impl;

import com.ecom.retail.entity.Product;
import com.ecom.retail.repository.ProductRepository;
import com.ecom.retail.service.ProductService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {


    @Autowired
    private ProductRepository productRepository;


    @Override
    public List<Product> listActiveProducts() {
            return productRepository.findByActiveOrderByPostedDateDesc(true);
    }

//    @Override
//    public List<Product> searchProducts(String productName, BigDecimal minPrice, BigDecimal maxPrice, LocalDateTime minPostedDate, LocalDateTime maxPostedDate) {
//        return productRepository.searchProducts(productName, minPrice, maxPrice, minPostedDate, maxPostedDate);
//    }

    @Override
    public Product createProduct(Product product) {
        if (product.getPrice().compareTo(new BigDecimal(10000)) > 0) {
            throw new IllegalArgumentException("Product price exceeds $10,000.");
        }
        if (product.getPrice().compareTo(new BigDecimal(5000)) > 0) {
            product.setActive(false); // Push product to approval queue
        } else {
            product.setActive(true);
        }
        product.setPostedDate(LocalDateTime.now());
        return productRepository.save(product);


    }



    @Override
    public Product updateProduct(Long productId, Product product) {
        Product existingProduct = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found with id: " + productId));

        BigDecimal previousPrice = existingProduct.getPrice();
        BigDecimal newPrice = product.getPrice();

        if (newPrice.compareTo(previousPrice.multiply(BigDecimal.valueOf(1.5))) > 0) {
            existingProduct.setActive(false); // Push product to approval queue
        } else {
            existingProduct.setActive(true);
        }

        existingProduct.setName(product.getName());
        existingProduct.setPrice(newPrice);
        return productRepository.save(existingProduct);
    }

    @Override
    public void deleteProduct(Long productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found with id: " + productId));
        productRepository.delete(product);
    }
}


