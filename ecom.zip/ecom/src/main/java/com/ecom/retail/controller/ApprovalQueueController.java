package com.ecom.retail.controller;


import com.ecom.retail.service.ApprovalQueueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ecom.retail.entity.ApprovalQueue;

import java.util.List;

    @RestController
    @RequestMapping("/api/products/approval-queue")
    public class ApprovalQueueController {

        @Autowired
        private ApprovalQueueService approvalQueueService;


        @GetMapping
        public ResponseEntity<List<ApprovalQueue>> getProductsInApprovalQueue() {
            List<ApprovalQueue> productsInApprovalQueue = approvalQueueService.getProductsInApprovalQueue();
            return ResponseEntity.ok(productsInApprovalQueue);
        }

        @PutMapping("/{approvalId}/approve")
        public ResponseEntity<Void> approvalQueue(@PathVariable Long approvalId) {
            approvalQueueService.approvalQueue(approvalId);
            return ResponseEntity.noContent().build();
        }

        @PutMapping("/{approvalId}/reject")
        public ResponseEntity<Void> rejectedProduct(@PathVariable Long approvalId) {
            approvalQueueService.rejectedProduct(approvalId);
            return ResponseEntity.noContent().build();
        }
    }
