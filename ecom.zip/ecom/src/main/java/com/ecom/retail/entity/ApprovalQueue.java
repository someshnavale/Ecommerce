package com.ecom.retail.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "approval_queue")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalQueue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private Long productId;
    private boolean action;

    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

}
