package com.ecom.retail.service.impl;

import com.ecom.retail.entity.ApprovalQueue;
import com.ecom.retail.exception.ResourceNotFoundException;
import com.ecom.retail.repository.ApprovalQueueRepository;
import com.ecom.retail.service.ApprovalQueueService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@Transactional
public class ApprovalQueueServiceImpl implements ApprovalQueueService {


    @Autowired
    private ApprovalQueueRepository approvalQueueRepository;

    @Override
    public List<ApprovalQueue> getProductsInApprovalQueue() {
        return approvalQueueRepository.findAllByOrderByCreatedAtAsc();
    }

    @Override
    public void approvalQueue(Long approvalId) {
        ApprovalQueue approvalQueue = approvalQueueRepository.findById(approvalId)
                .orElseThrow(() -> new ResourceNotFoundException("Approval queue not found with id: " + approvalId));
        approvalQueue.setAction(true);
        approvalQueueRepository.save(approvalQueue);
    }

    @Override
    public void rejectedProduct(Long approvalId) {
        ApprovalQueue approvalQueue = approvalQueueRepository.findById(approvalId)
                .orElseThrow(() -> new ResourceNotFoundException("Approval queue not found with id: " + approvalId));
        approvalQueue.setAction(true);
        approvalQueueRepository.save(approvalQueue);
    }

}
